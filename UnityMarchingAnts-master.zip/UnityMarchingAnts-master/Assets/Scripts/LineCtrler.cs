
using System.Runtime.CompilerServices;
using UnityEngine;

public class LineCtrler : MonoBehaviour
{
    [SerializeField]
    private LineRenderer lineRenderer;
    private Material material;
    private Vector2 tiling;
    private Vector2 offset;
    private int mainTexProperty;

    // 飞机
    [SerializeField]
    private Transform airplane;

    // 线长
    private float lineLen;
    // 密度
    [SerializeField]
    private float density = 2f;

    // 定时器
    private float timer = 0;
    // 频率间隔
    [SerializeField]
    private float frequency = 0.03f;
    // 小蚂蚁爬行速度
    [SerializeField]
    private float moveSpeed = 0.04f;

    // 主摄像机
    private Camera mainCam;
    // 目标坐标
    private Vector3 targetPos;
    // 飞机飞行速度
    [SerializeField]
    private float flySpeed = 0.01f;
    // 是否到大目标坐标
    private bool reachTargetPos = false;


    void Start()
    {
        // 缓存材质实例
        material = lineRenderer.material;
        // 缓存属性id，防止下面设置属性的时候重复计算名字的哈希
        mainTexProperty = Shader.PropertyToID("_MainTex");

        tiling = new Vector2(20, 0);
        offset = new Vector2(0, 0);

        // 缓存摄像机
        mainCam = Camera.main;

        lineRenderer.enabled = false;
    }

    private void Update()
    {
        lineRenderer.SetPosition(0, airplane.position);

        // 计算线长度
        lineLen = (lineRenderer.GetPosition(1) - lineRenderer.GetPosition(0)).magnitude;
        // 根据线段长度计算Tiling
        tiling = new Vector2(lineLen * density, 0);

        // 设置Tiling
        material.SetTextureScale(mainTexProperty, tiling);


        timer += Time.deltaTime;
        if (timer >= frequency)
        {
            timer = 0;
            offset -= new Vector2(moveSpeed, 0);
            material.SetTextureOffset(mainTexProperty, offset);
        }

        // ----------------------------------------------------------------------------------
        // 严格来说，飞机的逻辑不应该写在LineCtrler中
        // 这里只是演示，所以我就不单独写到新的脚本啦
        if (Input.GetMouseButtonDown(0))
        {
            var screenPos = Input.mousePosition;
            // 屏幕坐标转世界坐标，注意z轴是距离摄像机的距离
            targetPos = mainCam.ScreenToWorldPoint(new Vector3(screenPos.x, screenPos.y, 10));
            // 这里用up是因为飞机的朝向的方向是y轴的方向，如果你的飞机的朝向是z轴的，则用forward
            airplane.up = targetPos - airplane.position;
            // 设置LineRenderer的终点
            lineRenderer.SetPosition(1, targetPos);
            reachTargetPos = false;
            lineRenderer.enabled = true;
        }
        if (!reachTargetPos)
        {
            // 飞机飞向目标的
            airplane.position += airplane.up * flySpeed;

            // 检测是否到达目标坐标
            if (Vector3.Dot(airplane.up, targetPos - airplane.position) < 0)
            {
                airplane.position = targetPos;
                reachTargetPos = true;
                lineRenderer.enabled = false;
            }
        }

    }
}
